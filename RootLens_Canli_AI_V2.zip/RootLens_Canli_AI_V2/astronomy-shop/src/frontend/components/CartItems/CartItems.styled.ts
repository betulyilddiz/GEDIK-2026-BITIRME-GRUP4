// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

import styled from 'styled-components';

export const CartItems = styled.section`
  display: flex;
  flex-direction: column;
`;

export const CardItemsHeader = styled.div`
  display: grid;
  grid-template-columns: 150px 100px auto auto;
  gap: 24px;

  ${({ theme }) => theme.breakpoints.desktop} {
    grid-template-columns: 1fr 120px 110px 110px;
  }

  > label:nth-child(2) {
    text-align: center;
  }

  > label:nth-child(n+3) {
    text-align: right;
  }
`;

export const CartItemImage = styled.img`
  width: 100%;
  height: auto;
  border-radius: 5px;
  object-fit: contain;

  ${({ theme }) => theme.breakpoints.desktop} {
    width: 120px;
    height: 120px;
  }
`;

export const CartItem = styled.div`
  display: grid;
  grid-template-columns: 150px 100px auto auto;
  gap: 24px;
  padding: 24px 0;
  align-items: center;
  border-bottom: 1px solid ${({ theme }) => theme.colors.textLightGray};

  ${({ theme }) => theme.breakpoints.desktop} {
    grid-template-columns: 1fr 120px 110px 110px;
  }

  > :nth-child(2) {
    display: flex;
    justify-content: center;
  }

  > :nth-child(n+3) {
    align-items: flex-end;
  }
`;

export const CartItemDetails = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

export const NameContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 5px;
  flex-direction: column;
  cursor: pointer;

  ${({ theme }) => theme.breakpoints.desktop} {
    flex-direction: row;
    gap: 24px;
  }
`;

export const PriceContainer = styled.div`
  display: flex;
  width: 100%;
  justify-content: flex-end;
`;

export const DataRow = styled.div`
  display: flex;
  justify-content: flex-end;
  padding: 24px 0;
  gap: 24px;
`;

export const TotalText = styled.h3`
  margin: 0;
`;
