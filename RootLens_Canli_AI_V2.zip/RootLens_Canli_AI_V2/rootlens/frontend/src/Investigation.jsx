import { useEffect, useRef, useState } from "react";
import "./investigation.css";

const suggestions = [
  ["Ne yaptık?", "completed"],
  ["Yapay zekâ ne yapıyor?", "model"],
  ["İlk aday neden bu servis?", "root"],
  ["Ne eksik kaldı?", "remaining"],
];

const project = {
  goal: "Bir sipariş aksadığında önce hangi servislerin etkilendiğini, sonra sorunun hangi servisten başlamış olabileceğini buluyoruz.",
  completed: "Canlı Order ve Payment deneyini kurduk. Gerçek HTTP isteklerinden gecikme, hata ve çağrı izleri topluyoruz. One-Class SVM normal davranışı öğreniyor. RootLens şüpheli servisleri sıralıyor ve sonuçları panelde gösteriyor.",
  remaining: "Aynı akışı Astronomy Shop üzerinde Prometheus, OpenSearch ve Jaeger ile uçtan uca doğrulamak kaldı. Ardından arızaları tekrar edip yöntemlerin sonuçlarını tez ve makaleye aktaracağız.",
};

const formatScore = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 2 }).format;
const formatPercent = new Intl.NumberFormat("tr-TR", { style: "percent", maximumFractionDigits: 1 }).format;

function summary(context) {
  const { result, bucket, windows, method } = context;
  if (!result) return ["Bir deney çalıştırınca etkilenen servisleri, ilk kök neden adayını ve buna dayanak olan verileri burada açıklayacağım."];
  if (!bucket) return ["Analiz tamamlandı. Seçilen test aralığında değerlendirilebilen tam bir servis penceresi bulunamadı."];
  const scored = windows.filter((item) => item.scores[method] != null);
  if (!scored.length) return ["Bu zaman penceresinde seçili yöntemin skor üretmesi için yeterli veri veya normal referans yok."];
  const affected = scored.filter((item) => item.scores[method] > 1).map((item) => item.service);
  const lead = bucket.rankings[method]?.[0];
  if (!lead) return ["Bu zaman penceresinde seçili yöntem anomali eşiğini aşan bir servis bulmadı."];
  return [
    `Bu zaman penceresinde ${affected.join(" ve ")} için anomali işaretlendi. İlk kök neden adayı ${lead.service}.`,
    lead.downstream_trace_count
      ? `Sıralama, anomali skorlarıyla birlikte ${lead.downstream_trace_count} çağrı izini dikkate aldı.`
      : "Bu aday seçili yöntemin skorlarına göre sıralandı.",
  ];
}

function answer(topic, context) {
  const { result, bucket, windows, method, methodLabel } = context;
  switch (topic) {
    case "goal":
      return [project.goal];
    case "completed":
      return [project.completed];
    case "remaining":
      return [project.remaining];
    case "model": {
      const trained = Object.entries(result?.model?.services || {});
      return [
        "Anomaliyi One-Class SVM tespit eder. Model, önceki normal zaman pencerelerindeki servis davranışını öğrenir ve sonraki ölçümlerin bu davranıştan sapıp sapmadığını değerlendirir. Kök neden sıralaması ayrı bir adımdır.",
        trained.length
          ? `Bu deneyde eğitimde ${trained.map(([service, data]) => `${service} için ${data.training_windows} normal pencere`).join(", ")} kullanıldı.`
          : "Eğitilen servisler ve pencere sayıları analiz tamamlandığında görünür.",
      ];
    }
    case "root": {
      const lead = bucket?.rankings[method]?.[0];
      if (!lead) return summary(context);
      const edges = bucket.edges.filter((edge) => edge.callee === lead.service);
      const usesTrace = ["OneClassSVM", "Fused", "Jaeger"].includes(method);
      const ties = bucket.rankings[method].filter((item) => item.rank_score === lead.rank_score).length;
      return [
        `${methodLabel} yönteminde ${lead.service} ilk sırada. Anomali skoru ${formatScore(lead.score)}, sıralama skoru ${formatScore(lead.rank_score)}.`,
        usesTrace && lead.downstream_trace_count && edges.length
          ? `Çağrı izlerinde ${edges.map((edge) => `${edge.caller} → ${edge.callee} (${edge.traces} iz)`).join(", ")} görüldü. Bu yöntemde anomali görülen servisler arasındaki çağrı ilişkileri sıralamayı etkiler.`
          : ties > 1
            ? "İlk sıradaki skor birden fazla serviste aynı. Bu sonuç tek bir kök nedeni ayırmaya yetmiyor."
            : "Bu pencerenin sonucu, seçili yöntemin kullandığı ölçümlere göre bir kök neden adayıdır.",
      ];
    }
    case "evidence": {
      if (!bucket) return summary(context);
      const traces = bucket.edges.map((edge) => `${edge.caller} → ${edge.callee} (${edge.traces} iz)`);
      return [
        traces.length ? `Çağrı izlerinde ${traces.join(", ")} görüldü.` : "Bu zaman penceresinde servisler arası çağrı izi bulunmadı.",
        ...windows.filter((window) => window.scores[method] != null).map((window) =>
          `${window.service} için anomali skoru ${formatScore(window.scores[method])}. ${Object.values(window.evidence)
            .map((item) => `${item.signal} ${formatScore(item.value)} (istatistiksel eşik ${formatScore(item.threshold)})`).join(" · ")}`),
      ];
    }
    case "metrics": {
      const evaluation = result?.evaluation;
      const row = evaluation?.methods[method];
      return [
        "F1, anomali tespitinin performansını özetler. Top-1, doğru servisin kök neden listesinde kaç deney penceresinde ilk sıraya geldiğini gösterir.",
        row && evaluation.common_windows
          ? `Bu deneyde ${methodLabel} için F1 ${row.f1 == null ? "hesaplanamadı" : formatPercent(row.f1)} (${evaluation.common_windows} servis penceresi). Top-1 ${row.top1 == null ? "hesaplanamadı" : formatPercent(row.top1)} (${evaluation.common_root_windows} kök neden penceresi).`
          : "Bu yöntem için ortak etiketli test sonucu henüz yok.",
      ];
    }
    case "summary":
      return summary(context);
    default:
      return ["Deney sonuçları ve proje ilerlemesi hakkında yardımcı olabilirim. Modelin nasıl çalıştığını, ilk kök neden adayını, çağrı izlerini, F1 ve Top-1 sonuçlarını ya da kalan işleri sorabilirsin."];
  }
}

function questionTopic(question) {
  const text = question.toLocaleLowerCase("tr-TR").normalize("NFD").replace(/\p{Diacritic}/gu, "").replaceAll("ı", "i");
  if (/eksik|kaldi|kalan|sirada ne|ne yapacag|sonraki/.test(text)) return "remaining";
  if (/amac|hedef|neyi bul|neden yapi/.test(text)) return "goal";
  if (/yaptik|tamamlan|bitti|proje durum/.test(text)) return "completed";
  if (/hangi servis.*(anomali|etkilen)|ne oldu/.test(text)) return "summary";
  if (/yapay|model|svm|egitim|ogren/.test(text)) return "model";
  if (/f1|top[ -]?[13]|basari|precision|performans|karsilastir/.test(text)) return "metrics";
  if (/kok|aday|payment|odeme|siralam/.test(text)) return "root";
  if (/kanit|trace|cagri|metrik|log/.test(text)) return "evidence";
  if (/sonuc|ozet|anomali|ne oldu/.test(text)) return "summary";
  return null;
}

export function Investigation({ result, bucket, windows, method, methodLabel, onTechnical }) {
  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState("");
  const thread = useRef(null);
  const context = { result, bucket, windows, method, methodLabel };
  const lead = bucket?.rankings[method]?.[0];
  const affected = windows.filter((window) => (window.scores[method] || 0) > 1);
  const hasScores = windows.some((window) => window.scores[method] != null);
  const edge = (lead && bucket.edges.find((item) => item.callee === lead.service)) || bucket?.edges[0];

  useEffect(() => {
    if (messages.length && thread.current) thread.current.scrollTop = thread.current.scrollHeight;
  }, [messages]);

  function ask(question, topic) {
    const clean = question.trim();
    if (!clean) return;
    setMessages((current) => [...current, { question: clean, reply: answer(topic || questionTopic(clean), context) }]);
    setDraft("");
  }

  return (
    <div className="investigation-layout" id="rootlens-conversation">
      <section className="investigation-card investigation-chat" aria-labelledby="investigation-heading">
        <header className="investigation-card-header">
          <span className="investigation-avatar" aria-hidden="true">✦</span>
          <div><h2 id="investigation-heading">Analiz asistanı</h2><p>Deney sonuçlarına dayalı yerel açıklamalar</p></div>
          <span className="investigation-tag">SORU / CEVAP</span>
        </header>
        <div className="investigation-thread" role="log" aria-label="Analiz konuşması" ref={thread} tabIndex={0}>
          <div className="investigation-message">
            {summary(context).map((line) => <p key={line}>{line}</p>)}
          </div>
          {messages.map((message, index) => (
            <div className="investigation-exchange" key={index}>
              <p className="investigation-question">{message.question}</p>
              <div className="investigation-message">
                {message.reply.map((line, replyIndex) => <p key={replyIndex}>{line}</p>)}
              </div>
            </div>
          ))}
        </div>
        <div className="investigation-composer">
          <div className="investigation-suggestions" aria-label="Örnek sorular">
            {suggestions.map(([question, topic]) => <button type="button" key={topic} onClick={() => ask(question, topic)}>{question}</button>)}
          </div>
          <form onSubmit={(event) => { event.preventDefault(); ask(draft); }}>
            <label className="investigation-visually-hidden" htmlFor="rootlens-question">Analiz hakkında soru yaz</label>
            <input id="rootlens-question" value={draft} maxLength={500} onChange={(event) => setDraft(event.target.value)} placeholder="Örn. Model hangi serviste anomali gördü?" />
            <button type="submit" disabled={!draft.trim()} aria-label="Soruyu gönder">↑</button>
          </form>
        </div>
      </section>

      <section className="investigation-card investigation-findings" aria-labelledby="findings-heading">
        <header className="investigation-card-header">
          <div><p className="eyebrow">SEÇİLİ ZAMAN PENCERESİ</p><h2 id="findings-heading">Deney özeti</h2></div>
          <span className="investigation-tag">{result ? "SONUÇ HAZIR" : "BEKLENİYOR"}</span>
        </header>
        <dl>
          <div>
            <dt>İlk kök neden adayı</dt>
            <dd className={lead ? "investigation-primary-finding" : ""}>{lead?.service || (result ? "Aday bulunamadı" : "Deneyden sonra")}</dd>
          </div>
          <div>
            <dt>Anomali görülen servisler</dt>
            <dd>{affected.length ? affected.map((item) => item.service).join(", ") :
              hasScores ? "Anomali işaretlenmedi" : bucket ? "Veri yetersiz" : "—"}</dd>
          </div>
          <div>
            <dt>Gözlenen servis çağrısı</dt>
            <dd>{edge ? <><span>{edge.caller} → {edge.callee}</span><small>{edge.traces} iz</small></> : "—"}</dd>
          </div>
        </dl>
        <p className="investigation-context">{result ? `Seçili yöntem · ${methodLabel}` : "Tespit ve kök neden sıralaması deneyden sonra burada görünür."}</p>
        {result && <a className="investigation-details-link" href="#rootlens-technical" onClick={onTechnical}>Teknik sonuçları aç <span aria-hidden="true">↓</span></a>}
      </section>
    </div>
  );
}

export function ProjectStatus() {
  return (
    <section className="investigation-project" id="rootlens-project" aria-labelledby="project-heading">
      <header><p className="eyebrow">GRUP 4 / ROOTLENS</p><h2 id="project-heading">Proje nerede?</h2></header>
      <div>
        {[
          ["01", "Neyi buluyoruz?", project.goal],
          ["02", "Ne yaptık?", project.completed],
          ["03", "Ne kaldı?", project.remaining],
        ].map(([step, title, text]) => (
          <article key={step}><span>{step}</span><h3>{title}</h3><p>{text}</p></article>
        ))}
      </div>
    </section>
  );
}
